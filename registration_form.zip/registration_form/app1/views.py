from django.shortcuts import render
from app1.forms import Signup
from django.contrib import messages
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import authenticate,login,logout
# Create your views here.

def signup(request):
    if request.method=='POST':
        fm = Signup(request.POST)
        if fm.is_valid():
            messages.success(request,'account created sucssesfully')
            fm.save()
    else:
        fm = Signup()
    return render(request,'signup.html',{'form':fm})


def login(request):
    pass




